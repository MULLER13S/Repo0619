alert("Welcome to my JavaScript page!");
