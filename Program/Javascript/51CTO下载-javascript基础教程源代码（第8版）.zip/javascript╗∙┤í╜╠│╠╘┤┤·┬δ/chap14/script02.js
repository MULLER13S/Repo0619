$(document).ready(function() {
	$("#welcome").append("Welcome to jQuery!");
});