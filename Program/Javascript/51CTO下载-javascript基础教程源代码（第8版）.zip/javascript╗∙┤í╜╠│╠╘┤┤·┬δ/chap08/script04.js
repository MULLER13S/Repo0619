window.onblur = moveUp;

function moveUp() {
	self.focus();
}
